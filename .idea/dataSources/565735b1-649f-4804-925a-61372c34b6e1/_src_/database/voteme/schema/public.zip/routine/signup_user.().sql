create function signup_user() returns trigger
LANGUAGE plpgsql
AS $$
DECLARE
  user_role_id INTEGER;
  the_same_username_user auth.users%ROWTYPE;
BEGIN
  SELECT * INTO the_same_username_user
  FROM auth.users AS all_users
  WHERE all_users.user_username = NEW.user_username AND all_users.user_id != NEW.user_id;
  IF FOUND THEN
    RAISE EXCEPTION 'Username already exists : %', NEW.user_username;
  ELSE
    SELECT role_id INTO user_role_id
    FROM auth.roles
    WHERE role_name = 'ROLE_USER';

    INSERT INTO auth.user_roles(user_id, role_id)
    VALUES (new.user_id, user_role_id);
  END IF;

  RETURN NEW;
END;
$$;
