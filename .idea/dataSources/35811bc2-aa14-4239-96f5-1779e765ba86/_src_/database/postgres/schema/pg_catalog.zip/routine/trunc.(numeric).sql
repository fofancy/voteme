create function pg_catalog.trunc(numeric) returns numeric
IMMUTABLE
LANGUAGE SQL
AS $$
select pg_catalog.trunc($1,0)
$$;
