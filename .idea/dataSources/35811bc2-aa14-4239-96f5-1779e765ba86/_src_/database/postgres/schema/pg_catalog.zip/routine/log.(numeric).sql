create function pg_catalog.log(numeric) returns numeric
IMMUTABLE
LANGUAGE SQL
AS $$
select pg_catalog.log(10, $1)
$$;
